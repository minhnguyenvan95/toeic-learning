<?php
	return [
		'title' => [
			'register' => 'Register',
			'login' => 'Login'
		]
	];
?>