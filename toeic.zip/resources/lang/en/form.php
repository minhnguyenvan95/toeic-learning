<?php
return [
	'register' => 'Register',
	'login' => 'Login',
	'email' => 'Email Address',
	'password' => 'Password',
	'password_confirmation' => 'Confirm Password',
	'name' => 'Full Name',
];
?>