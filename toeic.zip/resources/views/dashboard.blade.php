@extends('app.layout')
@section('dashboard') current-menu-item @endsection

@section('title') @lang('app.title.login') @endsection

@section('maincontent')
<div class="fullwidth-block" id="page-register">
<div class="default-bg">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="boxed-section request-form">
      hihi
		  
      </div>
      </div>
    </div>
  </div>
</div>
</div>
@endsection