<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
<title><?php $__env->startSection('title'); ?><?php echo $__env->yieldSection(); ?></title>
<link href="<?php echo e(url('css/app.css')); ?>" rel="stylesheet" type="text/css">
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
<script type="text/javascript">
	var API = "<?php echo e(url('/api/v1/')); ?>";
</script>
<style>

</style>
</head>
<body>
<div class="container">
<div class="row">
<?php $__env->startSection('body'); ?><?php echo $__env->yieldSection(); ?>
</div>
</div>

<script type="text/javascript" src="<?php echo e(url('js/app.js?v=1')); ?>"></script>
</body>
</html>
