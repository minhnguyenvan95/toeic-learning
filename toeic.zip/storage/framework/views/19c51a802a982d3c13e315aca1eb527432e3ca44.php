<?php $__env->startSection('register'); ?> current-menu-item <?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?> <?php echo app('translator')->getFromJson('app.title.register'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('maincontent'); ?>
<div class="fullwidth-block" id="page-register">
<div class="default-bg">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="boxed-section request-form">
        <h2 class="section-title text-center"><?php echo app('translator')->getFromJson('form.register'); ?></h2>

        <form id="register-form" method="post" action="<?php echo e(url('api/v1/user/create')); ?>">
          <div class="field">
            <label for="Email"><?php echo app('translator')->getFromJson('form.email'); ?></label>
            <input type="email" class="control" id="Email" placeholder="<?php echo app('translator')->getFromJson('form.email'); ?>" name="email" required="required">
          </div>
          <div class="field">
            <label for="name"><?php echo app('translator')->getFromJson('form.name'); ?></label>
            <input type="text" class="control" id="name" placeholder="<?php echo app('translator')->getFromJson('form.name'); ?>" name="name" required="required">
          </div>
          <div class="field">
            <label for="Password"><?php echo app('translator')->getFromJson('form.password'); ?></label>
            <input type="password" class="control" id="Password" placeholder="<?php echo app('translator')->getFromJson('form.password'); ?>" name="password" required="required">
          </div>
          <div class="field">
            <label for="password_confirmation"><?php echo app('translator')->getFromJson('form.password_confirmation'); ?></label>
            <input type="password" class="control" id="password_confirmation" placeholder="<?php echo app('translator')->getFromJson('form.password_confirmation'); ?>" name="password_confirmation" required="required">
          </div>
          <div class="field no-label">
            <div class="control">
              <input type="submit" class="button fix-position" value="Submit request">
            </div>
          </div>
          <div class="status"></div>
        </form>
      </div>
      </div>
    </div>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>