<?php $__env->startSection('dashboard'); ?> current-menu-item <?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?> <?php echo app('translator')->getFromJson('app.title.login'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('maincontent'); ?>
<div class="fullwidth-block" id="page-register">
<div class="default-bg">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="boxed-section request-form">
      hihi
		  
      </div>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>