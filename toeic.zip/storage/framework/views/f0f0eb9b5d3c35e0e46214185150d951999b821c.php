<div class="primary-header">
	<div class="container">
		<a href="<?php echo e(url('')); ?>" id="branding">
			<img src="<?php echo e(url('images/logo.png')); ?>" alt="Lincoln high School">
			<h1 class="site-title">Toeic Learning</h1>
		</a> <!-- #branding -->
		
		<div class="main-navigation">
			<button type="button" class="menu-toggle"><i class="fa fa-bars"></i></button>
			<ul class="menu">
				<li class="menu-item <?php $__env->startSection('homepage'); ?><?php echo $__env->yieldSection(); ?>"><a href="<?php echo e(url('')); ?>">Home</a></li>
				<li class="menu-item <?php $__env->startSection('courses'); ?><?php echo $__env->yieldSection(); ?>"><a href="<?php echo e(url('courses')); ?>">Courses</a></li>
				<li class="menu-item <?php $__env->startSection('posts'); ?><?php echo $__env->yieldSection(); ?>"><a href="<?php echo e(url('posts')); ?>">Posts</a></li>
				<?php if(Auth::guest()): ?>
				<li class="menu-item <?php $__env->startSection('register'); ?><?php echo $__env->yieldSection(); ?>"><a href="<?php echo e(url('register')); ?>">Register</a></li>
				<li class="menu-item <?php $__env->startSection('login'); ?><?php echo $__env->yieldSection(); ?>"><a href="<?php echo e(url('login')); ?>">Login</a></li>
				<?php else: ?>
				<li class="menu-item <?php $__env->startSection('dashboard'); ?><?php echo $__env->yieldSection(); ?>"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
				<li class="menu-item"><a href="<?php echo e(url('logout')); ?>">Logout</a></li>
				<?php endif; ?>
			</ul> <!-- .menu -->
		</div> <!-- .main-navigation -->

		<div class="mobile-navigation"></div>
	</div> <!-- .container -->
</div> <!-- .primary-header -->