<?php $__env->startSection('login'); ?> current-menu-item <?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?> <?php echo app('translator')->getFromJson('app.title.login'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('maincontent'); ?>
    <div class="container-fluid">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <div class="boxed-section">
        <div id="question-nav"></div>
        <div id="question-wrapper" data-type="<?php echo e($type); ?>"></div>
        <?php if( isset($isPackage) ): ?>
          <?php echo e(count($data)); ?>

          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <?php echo html_entity_decode($package->content); ?>


          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?> 

        <?php endif; ?>
      </div>
      </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>